function initiate(){
	console.log("Initiating !")
	console.log( Math.floor((Math.random() * 36) + 1));	
	$("#result").val(46434)





}

$("#startbtn").on("click", function() {
  

  var baseBetvalue = $("#baseBet").val();
  console.log("Handler for `click` called.");
  $("#result").val(Math.round( Math.random() * 35 +1 ))
  if(next_choice){
    $("#firstHalf > div").text(2*baseBetvalue)
  }


  
} );


function first_bet(){

  
	
}



$( document ).ready(function() {
	game_num = 0;	
    console.log( "ready!" );
    console.log( "Game number", game_num);
    initiate();

//    console.log( Math.round( Math.random() * 35 +1 ));


    
});

function is_first_half(value){
  return value < 19
}
function is_second_half(value){
  return value >= 19
}

function is_red(value){
  return [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(value)
}
function is_black(value){
  return [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35].includes(value)
}

function is_odd(value){
  return value % 2 == 1
}
function is_even(value){
  return value % 2 == 0
}
function next_choice(){
  return (Math.round( Math.random() * 100 +1 ) % 2) == 1
}